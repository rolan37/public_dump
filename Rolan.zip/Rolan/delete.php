<?php

  include('connection.php');


?>



DELETE FROM 'table_name' WHERE full_name = $full_name;