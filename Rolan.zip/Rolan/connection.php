<?php

  $host= "localhost";
  $dbname = "rolan_pereira";
  $dbuser = "root";
  $dbpass = "";

  $conn = mysqli_connect($host,$dbuser,$dbpass,$dbname);

  if (mysqli_connect_error()){
  	die('Connect Error ('.mysqli_connect_errno().')'. mysqli_connect_error());
  }

  else{
  	echo 'we are connected';
  }

?>




