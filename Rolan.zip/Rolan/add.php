<?php

  include('connection.php');

$fn = $_POST['name'];
$ag = $_POST['age'];
$em = $_POST['email'];
$cn = $_POST['contact'];

$query  = "INSERT INTO `school_registration_form` (`full_name`, `age`, `email`, `number`, `id`) VALUES ('$fn', '$ag', '$em', '$cn', '$id');"

$a = mysqli_query($conn,$query);

if ($a){
  echo "data inserted";
}
else{
  echo "something went wrong";
}
?>






