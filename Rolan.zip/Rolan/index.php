<?php

  include('connection.php');


?>




<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Forms</title>
</head>
<body>

	<div class="main_form">


		<p class="form_title">School Registration Form</p>

<form method="POST" action="add.php">
	<label class="lbl_form">Full Name</label>
	<input type="name" name="name" placeholder="name" autocomplete="none" value="full_name"><br>

	<label class="lbl_form">Age</label>
	<input type="number" name="age" placeholder="age" value="age"><br>

	<label class="lbl_form">email</label>
	<input type="email" name="email" placeholder="email" value="email"><br>

	<label class="lbl_form">Contact Number</label>
	<input type="number" name="contact" placeholder="contact number" value="number"><br><br>

	<button type="submit" onclick="add.php" >Submit</button>
	
</form>
	

	</div>

</body>
</html>



<?php

$fn = $_GET['name'];
$ag = $_GET['age'];
$em = $_GET['email'];
$cn = $_GET['contact'];



?>
